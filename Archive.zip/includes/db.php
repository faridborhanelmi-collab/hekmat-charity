<?php
// Database Configuration
$host = 'localhost';
$dbname = 'hekmat_charity';
$username = 'root'; // Change later for production
$password = '';     // Change later for production
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    // $pdo = new PDO($dsn, $username, $password, $options);
    // echo "Connected successfully"; // Debugging
} catch (\PDOException $e) {
    // In production, log this instead of showing it
    // error_log($e->getMessage());
    // die("Database connection failed. Please try again later.");

    // For development, we can verify the file is loaded
    // echo "Connection logic ready.";
}
?>