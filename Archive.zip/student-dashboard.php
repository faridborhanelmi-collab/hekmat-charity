<?php
session_start();
// Auth Guard
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$userName = $_SESSION['user_name'] ?? 'دانش‌آموز';

// Logout Logic
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل دانش‌آموزی</title>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@100;300;400;500;700&display=swap"
        rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: { extend: { fontFamily: { sans: ['Vazirmatn', 'sans-serif'] } } }
        }
    </script>
</head>

<body class="bg-gray-50 min-h-screen">

    <!-- Navbar -->
    <nav class="bg-white shadow px-4 py-4">
        <div class="container mx-auto flex justify-between items-center">
            <span class="font-bold text-lg text-blue-600">پنل آموزشی</span>
            <div class="flex items-center gap-4">
                <span class="text-gray-600 hidden sm:inline">سلام،
                    <?php echo htmlspecialchars($userName); ?>
                </span>
                <a href="?logout=true"
                    class="text-sm text-red-500 hover:text-red-700 border border-red-200 px-3 py-1 rounded">خروج</a>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <h1 class="text-2xl font-bold text-gray-800 mb-6">دوره‌های آموزشی من</h1>

        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!-- Card 1 -->
            <div class="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition">
                <div class="aspect-w-16 aspect-h-9 bg-gray-200 relative group">
                    <!-- Placeholder for Thumbnail or iFrame logic -->
                    <div class="absolute inset-0 flex items-center justify-center text-gray-400 bg-gray-100">
                        <span class="text-4xl text-gray-300">▶</span>
                    </div>
                </div>
                <div class="p-5">
                    <div class="text-xs text-blue-500 font-bold mb-2 uppercase tracking-wide">ریاضیات</div>
                    <h3 class="text-lg font-bold text-gray-900 mb-2">آموزش ریاضی پایه نهم - فصل اول</h3>
                    <p class="text-gray-500 text-sm mb-4">مجموعه ها و احتمال</p>
                    <button
                        class="w-full bg-blue-50 text-blue-600 font-medium py-2 rounded hover:bg-blue-100 transition">
                        مشاهده ویدیو
                    </button>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition">
                <div class="aspect-w-16 aspect-h-9 bg-gray-200 relative">
                    <div class="absolute inset-0 flex items-center justify-center text-gray-400 bg-gray-100">
                        <span class="text-4xl text-gray-300">▶</span>
                    </div>
                </div>
                <div class="p-5">
                    <div class="text-xs text-green-500 font-bold mb-2 uppercase tracking-wide">علوم تجربی</div>
                    <h3 class="text-lg font-bold text-gray-900 mb-2">فیزیک - نیرو و حرکت</h3>
                    <p class="text-gray-500 text-sm mb-4">تدریس کامل مبحث قوانین نیوتن</p>
                    <button
                        class="w-full bg-blue-50 text-blue-600 font-medium py-2 rounded hover:bg-blue-100 transition">
                        مشاهده ویدیو
                    </button>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition">
                <div class="aspect-w-16 aspect-h-9 bg-gray-200 relative">
                    <div class="absolute inset-0 flex items-center justify-center text-gray-400 bg-gray-100">
                        <span class="text-4xl text-gray-300">▶</span>
                    </div>
                </div>
                <div class="p-5">
                    <div class="text-xs text-purple-500 font-bold mb-2 uppercase tracking-wide">عربی</div>
                    <h3 class="text-lg font-bold text-gray-900 mb-2">قواعد عربی - فعل ماضی</h3>
                    <p class="text-gray-500 text-sm mb-4">آموزش ساده و کاربردی قواعد</p>
                    <button
                        class="w-full bg-blue-50 text-blue-600 font-medium py-2 rounded hover:bg-blue-100 transition">
                        مشاهده ویدیو
                    </button>
                </div>
            </div>
        </div>
    </div>

</body>

</html>