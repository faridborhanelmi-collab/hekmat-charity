<!DOCTYPE html>
<html lang="fa" dir="rtl"class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>بنیاد خیریه مهربانی - آینده‌ای روشن</title>
    
    <!-- Google Fonts: Vazirmatn -->
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Vazirmatn', 'sans-serif'],
                    },
                    colors: {
                        primary: {
                            50: '#f0fdfa',
                            100: '#ccfbf1',
                            500: '#14b8a6',
                            600: '#0d9488',
                            800: '#115e59', // Deep Teal
                            900: '#134e4a',
                        },
                        accent: {
                            500: '#fb7185', // Soft Coral
                            600: '#e11d48',
                        }
                    },
                    backgroundImage: {
                        'hero-pattern': "url('https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=2670&auto=format&fit=crop')",
                    }
                }
            }
        }
    </script>
    <link rel="stylesheet" href="style.css">
    <style>
        .glass-nav {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.3);
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
        }
        .glass-stats {
             background: rgba(255, 255, 255, 0.1);
             backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
        }
        
    </style>
</head>
<body class="bg-[#fafafa] text-gray-800 font-sans antialiased selection:bg-accent-500 selection:text-white">

    <!-- Navbar -->
    <nav class="glass-nav fixed top-0 w-full z-50 transition-all duration-300">
        <div class="container mx-auto px-6 py-4 flex justify-between items-center">
            <div class="flex items-center gap-2">
                <div class="w-10 h-10 bg-gradient-to-tr from-primary-600 to-primary-400 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg">
                    م
                </div>
                <span class="text-2xl font-black text-primary-900 tracking-tight">مهربانی</span>
            </div>
            
            <div class="hidden md:flex items-center space-x-reverse space-x-8 text-sm font-medium text-gray-600">
                <a href="#about" class="hover:text-primary-600 transition-colors">داستان ما</a>
                <a href="#transparency" class="hover:text-primary-600 transition-colors">شفافیت</a>
                <a href="#contact" class="hover:text-primary-600 transition-colors">تماس</a>
            </div>

            <div>
                <a href="login.php" class="relative overflow-hidden group bg-primary-800 text-white px-6 py-2.5 rounded-full font-medium text-sm transition-all hover:shadow-lg hover:shadow-primary-500/30">
                    <span class="relative z-10 group-hover:text-white transition-colors">ورود دانش‌آموزان</span>
                    <div class="absolute inset-0 h-full w-full scale-0 rounded-full transition-all duration-300 group-hover:scale-100 group-hover:bg-primary-700/50"></div>
                </a>
            </div>
        </div>
    </nav>

    <!-- Cinematic Hero Section -->
    <header class="relative h-screen w-full flex items-center justify-center overflow-hidden">
        <!-- Background Image Parallax Effect could go here if using JS, static for now -->
        <div class="absolute inset-0 bg-hero-pattern bg-cover bg-center bg-no-repeat fixed-bg transform scale-105"></div>
        
        <!-- Emotional Dark Overlay -->
        <div class="absolute inset-0 bg-gradient-to-b from-primary-900/80 via-primary-900/60 to-primary-900/90 mix-blend-multiply"></div>
        <div class="absolute inset-0 bg-black/30"></div>

        <div class="container mx-auto px-4 relative z-10 text-center text-white">
            <div class="animate-fade-in-up">
                <span class="inline-block py-1 px-3 rounded-full bg-white/10 backdrop-blur border border-white/20 text-xs font-light tracking-wider mb-6 text-primary-50">
                    همراه با رویاهای کودکان
                </span>
                <h1 class="text-5xl md:text-7xl lg:text-8xl font-black mb-8 leading-tight tracking-tight drop-shadow-xl">
                    بنیاد خیریه <span class="text-transparent bg-clip-text bg-gradient-to-r from-teal-200 to-emerald-200">مهربانی</span>
                </h1>
                <p class="text-lg md:text-2xl font-light text-gray-100 max-w-3xl mx-auto mb-12 leading-loose drop-shadow-md">
                    جایی که مهربانی شما جوانه می‌زند و آینده‌ای سرشار از امید برای کودکان سرزمینمان می‌سازد.
                </p>
                
                <div class="flex flex-col sm:flex-row items-center justify-center gap-4">
                    <a href="#donate" class="w-full sm:w-auto px-10 py-4 bg-accent-500 hover:bg-accent-600 text-white rounded-2xl font-bold shadow-2xl shadow-accent-500/40 transition-all transform hover:-translate-y-1 text-lg">
                        حمایت می‌کنم
                    </a>
                    <a href="#about" class="w-full sm:w-auto px-10 py-4 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/30 text-white rounded-2xl font-bold transition-all text-lg">
                        بیشتر بدانید
                    </a>
                </div>
            </div>
        </div>

        <!-- Floating Glass Stats Bar -->
        <div class="absolute bottom-10 left-4 right-4 md:left-auto md:right-auto md:w-full md:max-w-4xl md:bottom-20 z-20 animate-fade-in-up delay-600">
            <div class="glass-stats rounded-3xl p-6 md:p-8 flex flex-col md:flex-row justify-around items-center text-center text-white gap-6 md:gap-0 mx-auto">
                <div class="flex-1">
                    <div class="text-4xl font-bold mb-1">۸۰+</div>
                    <div class="text-sm font-light text-primary-100">کودک تحت پوشش</div>
                </div>
                <div class="hidden md:block w-px h-12 bg-white/20"></div>
                <div class="flex-1">
                    <div class="text-4xl font-bold mb-1">۱۰۰٪</div>
                    <div class="text-sm font-light text-primary-100">شفافیت مالی</div>
                </div>
                <div class="hidden md:block w-px h-12 bg-white/20"></div>
                <div class="flex-1">
                    <div class="text-4xl font-bold mb-1">۵ سال</div>
                    <div class="text-sm font-light text-primary-100">تجربه و اعتماد</div>
                </div>
            </div>
        </div>
        
        <!-- Scroll Indicator -->
        <div class="absolute bottom-6 left-1/2 transform -translate-x-1/2 text-white/50 animate-bounce">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
        </div>
    </header>

    <!-- Mission Section -->
    <section id="about" class="py-32 bg-[#fafafa] relative">
        <div class="container mx-auto px-6">
            <div class="text-center max-w-3xl mx-auto mb-20">
                <h2 class="text-4xl font-bold text-primary-900 mb-6">مسیر مهربانی ما</h2>
                <p class="text-gray-500 text-lg leading-relaxed">
                    ما معتقدیم آموزش حق همه کودکان است. با ایجاد بستری امن و شفاف، کمک‌های شما را مستقیماً به لبخند و دانش تبدیل می‌کنیم.
                </p>
            </div>

            <div class="grid md:grid-cols-3 gap-8">
                <!-- Card 1 -->
                <div class="group bg-white p-10 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 relative overflow-hidden">
                    <div class="absolute top-0 right-0 w-32 h-32 bg-primary-50 rounded-bl-full -mr-16 -mt-16 transition-all group-hover:scale-150 group-hover:bg-primary-100"></div>
                    <div class="relative z-10">
                        <div class="w-16 h-16 bg-primary-100 rounded-2xl flex items-center justify-center text-3xl mb-8 text-primary-600">
                            🎓
                        </div>
                        <h3 class="text-xl font-bold text-gray-800 mb-4">آموزش برابر</h3>
                        <p class="text-gray-500 leading-7">دسترسی به بهترین محتوای آموزشی برای کودکانی که استعداد دارند اما امکانات نه.</p>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="group bg-white p-10 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 relative overflow-hidden">
                     <div class="absolute top-0 right-0 w-32 h-32 bg-accent-50 rounded-bl-full -mr-16 -mt-16 transition-all group-hover:scale-150 group-hover:bg-accent-100"></div>
                     <div class="relative z-10">
                        <div class="w-16 h-16 bg-accent-100 rounded-2xl flex items-center justify-center text-3xl mb-8 text-accent-600">
                            ❤️
                        </div>
                        <h3 class="text-xl font-bold text-gray-800 mb-4">حمایت عاطفی</h3>
                        <p class="text-gray-500 leading-7">تنها پول کافی نیست. ما با مشاوره و همراهی، حامی قلب‌های کوچک آن‌ها نیز هستیم.</p>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="group bg-white p-10 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 relative overflow-hidden">
                     <div class="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-bl-full -mr-16 -mt-16 transition-all group-hover:scale-150 group-hover:bg-blue-100"></div>
                     <div class="relative z-10">
                        <div class="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center text-3xl mb-8 text-blue-600">
                            🔍
                        </div>
                        <h3 class="text-xl font-bold text-gray-800 mb-4">شفافیت مطلق</h3>
                        <p class="text-gray-500 leading-7">ریز به ریز هزینه‌ها در سایت منتشر می‌شود تا خیال شما از بابت امانت‌داری ما راحت باشد.</p>
                     </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Donation Masterpiece Section -->
    <section id="donate" class="py-32 relative overflow-hidden">
        <div class="absolute inset-0 bg-primary-900 skew-y-3 transform origin-bottom-right"></div>
        <div class="container mx-auto px-6 relative z-10">
            <div class="flex flex-col lg:flex-row items-center justify-between gap-16">
                
                <div class="lg:w-1/2 text-white">
                    <h2 class="text-4xl md:text-5xl font-bold mb-8 leading-tight">سهم شما در <br/>ساختن فردا</h2>
                    <p class="text-primary-100 text-lg leading-loose mb-10">
                        می‌توانید با مبلغی اندک، مسیر زندگی یک کودک را تغییر دهید. کمک‌های شما مستقیماً صرف خرید لوازم التحریر و کلاس‌های آموزشی می‌شود.
                    </p>
                    <ul class="space-y-4 mb-10">
                        <li class="flex items-center gap-4">
                            <span class="w-8 h-8 rounded-full bg-accent-500 flex items-center justify-center text-xs font-bold">1</span>
                            <span>هزینه یک ماه تحصیل: ۵۰۰,۰۰۰ تومان</span>
                        </li>
                        <li class="flex items-center gap-4">
                            <span class="w-8 h-8 rounded-full bg-accent-500 flex items-center justify-center text-xs font-bold">2</span>
                            <span>هزینه بسته لوازم التحریر: ۱,۰۰۰,۰۰۰ تومان</span>
                        </li>
                    </ul>
                </div>

                <div class="lg:w-1/2 w-full flex justify-center">
                    <!-- Credit Card Component -->
                    <div class="relative group perspective-1000 w-full max-w-md">
                        <div class="absolute -inset-1 bg-gradient-to-r from-accent-600 to-pink-600 rounded-[2rem] blur opacity-25 group-hover:opacity-75 transition duration-1000 group-hover:duration-200"></div>
                        <div class="relative w-full h-64 bg-gradient-to-br from-gray-900 to-gray-800 rounded-[2rem] shadow-2xl p-8 flex flex-col justify-between text-white border border-white/10 overflow-hidden transform transition-transform duration-500 hover:rotate-1 hover:scale-[1.02]">
                            
                            <!-- Card Decoration -->
                            <div class="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-white/5 rounded-full blur-3xl"></div>
                            <div class="absolute bottom-0 left-0 -ml-16 -mb-16 w-64 h-64 bg-accent-500/10 rounded-full blur-3xl"></div>

                            <div class="flex justify-between items-start">
                                <div class="text-xs font-mono text-gray-400">DEBIT CARD</div>
                                <svg class="w-12 h-12 text-white/80" fill="currentColor" viewBox="0 0 24 24">
                                     <path d="M2,10 L2,14 L22,14 L22,10 L2,10 Z M2,6 L2,8 L22,8 L2,6 Z m0,12 L22,18 L22,16 L2,16 L2,18 Z"/> 
                                </svg>
                            </div>

                            <div class="space-y-2 text-center my-4 group cursor-pointer" onclick="navigator.clipboard.writeText('5892101012345678'); alert('شماره کارت کپی شد!');">
                                <div class="text-xs text-gray-400">شماره کارت (برای کپی کلیک کنید)</div>
                                <div class="text-3xl font-mono font-bold tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-white via-gray-200 to-gray-400 dir-ltr select-all">
                                    5892 1010 1234 5678
                                </div>
                            </div>

                            <div class="flex justify-between items-end">
                                <div>
                                    <div class="text-[10px] text-gray-400 uppercase tracking-wider">نام صاحب حساب</div>
                                    <div class="font-medium tracking-wide">بنیاد خیریه مهربانی</div>
                                </div>
                                <div>
                                    <div class="text-[10px] text-gray-400 uppercase tracking-wider text-left">بانک</div>
                                    <div class="font-bold text-accent-500">سپه</div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Transparency Table -->
    <section id="transparency" class="py-32 bg-[#fafafa]">
        <div class="container mx-auto px-6">
            <div class="text-center mb-16">
                <span class="text-accent-500 font-bold tracking-wider text-sm">اعتماد شما سرمایه ماست</span>
                <h2 class="text-3xl font-bold text-gray-900 mt-2">آخرین هزینه‌کردها</h2>
            </div>

            <div class="max-w-4xl mx-auto bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
                <table class="w-full text-right">
                    <thead class="bg-gray-50 border-b border-gray-100">
                        <tr>
                            <th class="p-6 font-bold text-gray-600">شرح هزینه</th>
                            <th class="p-6 font-bold text-gray-600">تاریخ</th>
                            <th class="p-6 font-bold text-gray-600">مبلغ</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-50 text-gray-700">
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="p-6 font-medium">تهیه ۵۰ سری کتاب کمک آموزشی</td>
                            <td class="p-6 text-gray-500">۱۴ آبان ۱۴۰۲</td>
                            <td class="p-6 font-bold text-primary-600">۲۵,۰۰۰,۰۰۰ تومان</td>
                        </tr>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="p-6 font-medium">هزینه درمان دانش‌آموز (کد پرونده ۸۹)</td>
                            <td class="p-6 text-gray-500">۱۲ آبان ۱۴۰۲</td>
                            <td class="p-6 font-bold text-primary-600">۴,۵۰۰,۰۰۰ تومان</td>
                        </tr>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="p-6 font-medium">اجاره فضای آموزشی (پاییز)</td>
                            <td class="p-6 text-gray-500">۱ مهر ۱۴۰۲</td>
                            <td class="p-6 font-bold text-primary-600">۱۰,۰۰۰,۰۰۰ تومان</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <footer class="bg-gray-900 border-t border-gray-800 text-gray-400 py-16">
        <div class="container mx-auto px-6 text-center">
            <h3 class="text-2xl font-bold text-white mb-6">بنیاد خیریه مهربانی</h3>
            <p class="mb-8 max-w-lg mx-auto leading-loose">تلاشی برای ساختن دنیایی که در آن هیچ کودکی از تحصیل باز نماند.</p>
            <div class="text-sm">
                &copy; 2024 تمامی حقوق محفوظ است.
            </div>
        </div>
    </footer>

</body>
</html>