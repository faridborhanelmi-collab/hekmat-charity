<?php
session_start();
// Check if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: student-dashboard.php");
    exit();
}

$error = '';

// Simple Login Logic (Hardcoded for demo, normally would use DB)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Placeholder validation - in production check against DB
    if ($email === 'student@example.com' && $password === '123456') {
        $_SESSION['user_id'] = 1;
        $_SESSION['user_name'] = 'دانش‌آموز نمونه';
        header("Location: student-dashboard.php");
        exit();
    } else {
        $error = 'ایمیل یا رمز عبور اشتباه است.';
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود به پرتال دانش‌آموزی - بنیاد مهربانی</title>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@100;300;400;500;700&display=swap"
        rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: { extend: { fontFamily: { sans: ['Vazirmatn', 'sans-serif'] } } }
        }
    </script>
</head>

<body class="bg-gray-100 flex items-center justify-center min-h-screen">

    <div class="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md">
        <div class="text-center mb-8">
            <h1 class="text-2xl font-bold text-gray-800">ورود دانش‌آموزان</h1>
            <p class="text-gray-500 mt-2 text-sm">لطفا اطلاعات حساب کاربری خود را وارد کنید</p>
        </div>

        <?php if ($error): ?>
            <div class="bg-red-50 text-red-600 p-3 rounded-lg mb-4 text-sm text-center">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="mb-4">
                <label for="email" class="block text-gray-700 text-sm font-bold mb-2">ایمیل</label>
                <input type="email" id="email" name="email" required
                    class="shadow-sm appearance-none border rounded-lg w-full py-3 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 border-gray-200 transaction"
                    placeholder="student@example.com">
            </div>
            <div class="mb-6">
                <label for="password" class="block text-gray-700 text-sm font-bold mb-2">رمز عبور</label>
                <input type="password" id="password" name="password" required
                    class="shadow-sm appearance-none border rounded-lg w-full py-3 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 border-gray-200 transaction">
            </div>
            <div class="flex items-center justify-between mb-6">
                <!-- <a href="#" class="inline-block align-baseline font-bold text-sm text-blue-500 hover:text-blue-800">
                    رمز عبور را فراموش کردید؟
                </a> -->
            </div>
            <button type="submit"
                class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg focus:outline-none focus:shadow-outline transition">
                ورود به پنل
            </button>
        </form>

        <div class="mt-6 text-center">
            <a href="index.php" class="text-sm text-gray-500 hover:text-gray-800 transition">بازگشت به صفحه اصلی</a>
        </div>
    </div>

</body>

</html>